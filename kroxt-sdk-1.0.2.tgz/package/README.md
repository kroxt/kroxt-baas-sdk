# Kroxt SDK

Official JavaScript and TypeScript SDK for Kroxt BaaS.

## Installation

```bash
npm install @kroxt/sdk
```

## Quick Start

```ts
import Kroxt from "@kroxt/sdk";

const kroxt = new Kroxt({
  baseUrl: "https://api.example.com",
  projectId: "PROJECT_ID",
  apiKey: "PROJECT_API_KEY",
});

const posts = await kroxt.collection("posts").limit(10).get();
```

## Authentication

```ts
const session = await kroxt.auth.login({
  email: "user@example.com",
  password: "password",
});

const user = await kroxt.auth.me();

await kroxt.auth.logout();
```

You can also register project users:

```ts
await kroxt.auth.register({
  email: "user@example.com",
  password: "password",
  displayName: "Ada",
});
```

## Collections

```ts
type Post = {
  title: string;
  published: boolean;
  views: number;
};

const posts = kroxt.collection<Post>("posts");

const created = await posts.create({
  title: "Hello Kroxt",
  published: true,
  views: 1,
});

const publishedPosts = await posts
  .where("published", true)
  .where("views", "greaterThan", 10)
  .orderBy("createdAt", "desc")
  .limit(20)
  .get();

await posts.update(created._id, { views: 2 });
await posts.delete(created._id);
```

## Pagination

```ts
const page = await kroxt.collection("posts").paginate({
  page: 1,
  limit: 20,
});

console.log(page.items, page.total, page.hasNext);
```

## Realtime

```ts
const channel = kroxt.realtime.collection("posts");

channel
  .subscribe()
  .on("created", (post) => {
    console.log("New post:", post);
  });
```

Custom channels are also supported:

```ts
kroxt.realtime
  .channel("room:lobby")
  .subscribe()
  .on("message", (payload) => {
    console.log(payload);
  });
```

## Storage and Functions

```ts
const uploaded = await kroxt.storage.upload(file);

const result = await kroxt.functions.invoke("send-welcome-email", {
  userId: "USER_ID",
});
```

## Configuration

```ts
const kroxt = new Kroxt({
  projectId: "PROJECT_ID",
  apiKey: "PROJECT_API_KEY",
  baseUrl: "https://api.example.com",
  timeout: 30000,
  retries: 3,
  autoRefresh: true,
  debug: false,
});
```

## Package Formats

This package ships CommonJS, ESM, and TypeScript declarations.

```ts
import Kroxt from "@kroxt/sdk";
```

```js
const { Kroxt } = require("@kroxt/sdk");
```

## License

MIT
